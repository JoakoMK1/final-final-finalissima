import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-footer',
  styleUrl: './footer.css',
  templateUrl: './footer.html',
})
export class Footer {
  // Declaras la variable dentro de la clase para que el HTML pueda leerla
  imagenLogo: string = "LogoNegro.jpg";
}