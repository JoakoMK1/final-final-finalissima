import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Productos } from '../../models/interface/interface';
import { Producto } from '../../pages/producto/producto';
@Component({
  imports: [],
  selector: 'app-producto-card',
  styleUrl: './producto-card.css',
  templateUrl: './producto-card.html',
})
export class ProductoCard {
  @Input() producto: any;
  @Input() favorito: boolean = false;
  @Output() agregarafavoritos = new EventEmitter<number>();
  
  onAgregar(): void {
    this.agregarafavoritos.emit(this.producto.id);
}
}
