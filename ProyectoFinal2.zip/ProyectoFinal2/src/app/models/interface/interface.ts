export interface Productos {
id: number;
nombre: string;
precio: number;
precioOriginal?: number; 
descuento?: number;      
categoria: string;
imagen: string; 
}