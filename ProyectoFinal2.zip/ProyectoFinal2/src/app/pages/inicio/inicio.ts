import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
@Component({
  imports: [RouterLink],
  selector: 'app-inicio',
  styleUrl: './inicio.css',
  templateUrl: './inicio.html',
})
export class Inicio {
  imagenP: string = 'Fachada.png';
  imagenS: string = 'Monumental.jfif';
  imagen3: string = 'pelota.webp'

  constructor(private router: Router) {} // 2. Inyecta el Router

  // 3. Función que se ejecuta al hacer clic en el botón
  irProductos() {
    this.router.navigate(['/producto']);
}
}
