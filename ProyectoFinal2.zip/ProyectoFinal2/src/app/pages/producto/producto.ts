import { Component } from '@angular/core';
import { Productos } from '../../models/interface/interface';
import { ProductoCard } from '../../components/producto-card/producto-card';

@Component({
  imports: [ProductoCard],
  selector: 'app-producto',
  styleUrl: './producto.css',
  templateUrl: './producto.html',
})
export class Producto {
  producto: Productos[] = [
    { id: 1, nombre: 'Titular River 2026', precio: 28000, precioOriginal: 40000, descuento: 30, categoria: 'River', imagen: 'River1.webp' },
    { id: 2, nombre: 'Alternativa River 2026', precio: 40000, categoria: 'River', imagen: 'River2.jfif' },
    { id: 3, nombre: 'Tercera River', precio: 32499, precioOriginal: 49999, descuento: 35, categoria: 'River', imagen: 'River3.jfif' },
    { id: 4, nombre: 'River Edición Especial', precio: 49999, categoria: 'River', imagen: 'River4.jfif' },
    { id: 5, nombre: 'River Prematch', precio: 42499, precioOriginal: 49999, descuento: 15, categoria: 'River', imagen: 'River5.web' },
    { id: 6, nombre: 'River Aniversario', precio: 49999, categoria: 'River', imagen: 'River6.webp' },
    { id: 7, nombre: 'River Alternativa B', precio: 49999, categoria: 'River', imagen: 'River7.webp' },
    { id: 8, nombre: 'River Alternativa 2025', precio: 39999, precioOriginal: 49999, descuento: 20, categoria: 'River', imagen: 'River9.avif' },

    // --- BOCA ---
    { id: 9, nombre: 'Boca Alternativa 1', precio: 34999, precioOriginal: 49999, descuento: 30, categoria: 'Boca', imagen: 'Boca2.webp' },
    { id: 10, nombre: 'Boca Titular 1', precio: 49999, categoria: 'Boca', imagen: 'Boca3.webp' },
    { id: 11, nombre: 'Boca Alternativa 2', precio: 49999, categoria: 'Boca', imagen: 'Boca4.webp' },
    { id: 12, nombre: 'Boca Special 1', precio: 39999, precioOriginal: 49999, descuento: 20, categoria: 'Boca', imagen: 'Boca5.webp' },
    { id: 13, nombre: 'Boca Special 2', precio: 49999, categoria: 'Boca', imagen: 'Boca6.webp' },
    { id: 14, nombre: 'Boca Training', precio: 49999, categoria: 'Boca', imagen: 'Boca7.webp' },

    // --- RACING ---
    { id: 15, nombre: 'Racing Titular', precio: 31500, precioOriginal: 45000, descuento: 30, categoria: 'Racing', imagen: 'Racing1.png' },
    { id: 16, nombre: 'Racing Alternativa', precio: 45000, categoria: 'Racing', imagen: 'Racing2.jfif' },

    // --- INDEPENDIENTE ---
    { id: 17, nombre: 'Independiente Titular', precio: 45000, categoria: 'Independiente', imagen: 'Idependiente1.webp' },
    { id: 18, nombre: 'Independiente Alternativa', precio: 35100, precioOriginal: 45000, descuento: 22, categoria: 'Independiente', imagen: 'Independiente2.jfif' },
    { id: 19, nombre: 'Independiente Third', precio: 45000, categoria: 'Independiente', imagen: 'Independiente3.webp' },

    // --- SELECCIONES / INTERNACIONALES ---
    { id: 20, nombre: 'Selección Alemania 1', precio: 35750, precioOriginal: 55000, descuento: 35, categoria: 'Internacionales', imagen: 'Alemania1.webp' },
    { id: 21, nombre: 'Selección Alemania 2', precio: 55000, categoria: 'Internacionales', imagen: 'Alemania2.avif' },
    { id: 22, nombre: 'Selección Argentina 1', precio: 38500, precioOriginal: 55000, descuento: 30, categoria: 'Internacionales', imagen: 'Argentina1.webp' },
    { id: 23, nombre: 'Selección Argentina 2', precio: 55000, categoria: 'Internacionales', imagen: 'Argentina2.webp' },
    { id: 24, nombre: 'Selección Brasil 1', precio: 55000, categoria: 'Internacionales', imagen: 'Brasil1.jpg' },
    { id: 25, nombre: 'Selección Brasil 2', precio: 44000, precioOriginal: 55000, descuento: 20, categoria: 'Internacionales', imagen: 'Brasil2.webp' },
    { id: 26, nombre: 'Selección España 1', precio: 55000, categoria: 'Internacionales', imagen: 'España1.webp' },
    { id: 27, nombre: 'Selección España 2', precio: 55000, categoria: 'Internacionales', imagen: 'España2.webp' },
    { id: 28, nombre: 'Selección Francia', precio: 35750, precioOriginal: 55000, descuento: 35, categoria: 'Internacionales', imagen: 'Francia1.webp' },
    { id: 29, nombre: 'Selección Inglaterra 1', precio: 55000, categoria: 'Internacionales', imagen: 'Inglaterra1.webp' },
    { id: 30, nombre: 'Selección Inglaterra 2', precio: 55000, categoria: 'Internacionales', imagen: 'Inglaterra2.webp' },
    { id: 31, nombre: 'Selección Italia 1', precio: 55000, categoria: 'Internacionales', imagen: 'Italia.jpg' },
    { id: 32, nombre: 'Selección Italia 2', precio: 55000, categoria: 'Internacionales', imagen: 'Italia2.jpg' },
    { id: 33, nombre: 'Selección Japón', precio: 55000, categoria: 'Internacionales', imagen: 'Japon1.avif' },
    { id: 34, nombre: 'Selección Portugal', precio: 55000, categoria: 'Internacionales', imagen: 'Portugal1.webp' },

    // --- CLUBES EUROPEOS ---
    { id: 35, nombre: 'Barcelona Titular Actual', precio: 33800, precioOriginal: 52000, descuento: 35, categoria: 'Clubes', imagen: 'Barcelona1.webp' },
    { id: 36, nombre: 'Barcelona Titular 2025-26', precio: 52000, categoria: 'Clubes', imagen: 'Barcelona2.jpg' },
    { id: 37, nombre: 'Barcelona Third', precio: 52000, categoria: 'Clubes', imagen: 'Barcelona3.webp' },
    { id: 38, nombre: 'Manchester City 1', precio: 52000, categoria: 'Clubes', imagen: 'City1.jpg' },
    { id: 39, nombre: 'Manchester City 2', precio: 41600, precioOriginal: 52000, descuento: 20, categoria: 'Clubes', imagen: 'City2.jpg' },
    { id: 40, nombre: 'Manchester City 3', precio: 52000, categoria: 'Clubes', imagen: 'City3.jpg' },
    { id: 41, nombre: 'Liverpool 1', precio: 52000, categoria: 'Clubes', imagen: 'Liverpool1.png' },
    { id: 42, nombre: 'Liverpool 2', precio: 52000, categoria: 'Clubes', imagen: 'Liverpool2.jpg' },
    { id: 43, nombre: 'Real Madrid 1', precio: 33800, precioOriginal: 52000, descuento: 35, categoria: 'Clubes', imagen: 'Real1.webp' },
    { id: 44, nombre: 'Real Madrid 2', precio: 52000, categoria: 'Clubes', imagen: 'Real2.jfif' },
    { id: 45, nombre: 'Real Madrid 3', precio: 52000, categoria: 'Clubes', imagen: 'Real3.jfif' },
    { id: 46, nombre: 'Real Madrid 4', precio: 52000, categoria: 'Clubes', imagen: 'Real4.jfif' },
  ];

  fondo: string = "Fondo.jpg";
  categoriaActiva: string = 'todos';
  favoritos: number[] = [];
  productosFiltrados = this.producto;

  onAgregar(id: number): void {
    if (this.favoritos.includes(id)) {
      this.favoritos = this.favoritos.filter(favorito => favorito !== id);
    } else {
      this.favoritos.push(id);
    }
  }

  filtrar(categoria: string) {
    this.categoriaActiva = categoria;
    if (categoria === 'todos') {
      this.productosFiltrados = this.producto;
    } else {
      this.productosFiltrados = this.producto.filter(p => 
        p.categoria.toLowerCase() === categoria.toLowerCase()
      );
    }
  }

  esFavorito(id: number): boolean {
    return this.favoritos.includes(id);
  }
}