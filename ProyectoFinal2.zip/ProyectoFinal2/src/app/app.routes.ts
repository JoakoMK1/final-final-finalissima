import { Routes } from '@angular/router';
import { Inicio } from './pages/inicio/inicio';
import { Producto } from './pages/producto/producto';
import { Nosotros } from './pages/nosotros/nosotros';
import { Contacto } from './pages/contacto/contacto';
import { NotFound } from './pages/not-found/not-found';

export const routes: Routes = [
    {path: '', component:Inicio},
    {path: 'producto', component:Producto},
    {path:'nosotros', component:Nosotros},
    {path:'contacto', component:Contacto},
    {path:'**', component:NotFound}
];
